<?php

namespace App\Models\ferreteria;

use Illuminate\Database\Eloquent\Model;

class Rol_permiso extends Model
{
    //

}
