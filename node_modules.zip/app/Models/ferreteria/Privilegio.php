<?php

namespace App\Models\ferreteria;

use Illuminate\Database\Eloquent\Model;

class Privilegio extends Model
{
    //
}
